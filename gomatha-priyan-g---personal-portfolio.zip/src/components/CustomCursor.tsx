import { useEffect, useState } from 'react';

export default function CustomCursor() {
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [ringPosition, setRingPosition] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);
  const [isHidden, setIsHidden] = useState(true);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setPosition({ x: e.clientX, y: e.clientY });
      setIsHidden(false);
    };

    const handleMouseLeave = () => {
      setIsHidden(true);
    };

    // Smooth lag for outer circle
    let animationFrameId: number;
    const updateRing = () => {
      setRingPosition((prev) => {
        const dx = position.x - prev.x;
        const dy = position.y - prev.y;
        return {
          x: prev.x + dx * 0.15,
          y: prev.y + dy * 0.15,
        };
      });
      animationFrameId = requestAnimationFrame(updateRing);
    };

    window.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseleave', handleMouseLeave);
    animationFrameId = requestAnimationFrame(updateRing);

    // Track mouse hover states on interactive items
    const handleMouseOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (
        target.tagName === 'A' ||
        target.tagName === 'BUTTON' ||
        target.closest('a') ||
        target.closest('button') ||
        target.classList.contains('clickable')
      ) {
        setIsHovered(true);
      } else {
        setIsHovered(false);
      }
    };

    window.addEventListener('mouseover', handleMouseOver);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseleave', handleMouseLeave);
      window.removeEventListener('mouseover', handleMouseOver);
      cancelAnimationFrame(animationFrameId);
    };
  }, [position.x, position.y]);

  if (isHidden) return null;

  return (
    <>
      <div
        className="custom-cursor fixed pointer-events-none rounded-full z-[9999] transition-transform duration-100 ease-out"
        style={{
          left: `${position.x}px`,
          top: `${position.y}px`,
          transform: `translate(-50%, -50%) scale(${isHovered ? 1.8 : 1})`,
          backgroundColor: isHovered ? '#00C9A7' : '#00F5FF',
          boxShadow: isHovered
            ? '0 0 10px rgba(0, 201, 167, 0.8)'
            : '0 0 8px rgba(0, 245, 255, 0.8)',
        }}
      />
      <div
        className="custom-cursor-ring fixed pointer-events-none rounded-full z-[9998] transition-all duration-75 ease-out"
        style={{
          left: `${ringPosition.x}px`,
          top: `${ringPosition.y}px`,
          width: isHovered ? '50px' : '36px',
          height: isHovered ? '50px' : '36px',
          borderColor: isHovered ? 'rgba(0, 201, 167, 0.6)' : 'rgba(123, 47, 247, 0.5)',
          transform: 'translate(-50%, -50%)',
          boxShadow: isHovered ? '0 0 10px rgba(0, 201, 167, 0.2)' : 'none',
        }}
      />
    </>
  );
}
