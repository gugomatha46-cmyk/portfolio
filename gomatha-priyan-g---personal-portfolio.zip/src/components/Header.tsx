import { useState, useEffect } from 'react';
import { Menu, X, Sun, Moon, Sparkles } from 'lucide-react';

interface HeaderProps {
  isDarkMode: boolean;
  toggleTheme: () => void;
}

export default function Header({ isDarkMode, toggleTheme }: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      // Background blur effect on scroll
      setIsScrolled(window.scrollY > 20);

      // Scroll progress tracking
      const totalHeight = document.documentElement.scrollHeight - window.innerHeight;
      if (totalHeight > 0) {
        const progress = (window.scrollY / totalHeight) * 100;
        setScrollProgress(progress);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'About', href: '#about' },
    { name: 'Education', href: '#education' },
    { name: 'Skills', href: '#skills' },
    { name: 'Projects', href: '#projects' },
    { name: 'Future Goals', href: '#goals' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <header
      id="site-header"
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-slate-900/80 dark:bg-slate-950/80 backdrop-blur-md shadow-lg border-b border-white/5 py-3'
          : 'bg-transparent py-5'
      }`}
    >
      {/* Scroll Progress Bar */}
      <div className="scroll-progress" style={{ width: `${scrollProgress}%` }} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <a
            href="#"
            className="flex items-center gap-2 font-sans font-bold text-xl tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-cyan-glow via-purple-glow to-teal-glow hover:opacity-90 transition-opacity"
            id="nav-logo"
          >
            <Sparkles className="w-5 h-5 text-cyan-glow" />
            <span>GOMATHA PRIYAN G</span>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8" id="desktop-nav">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-sm font-medium text-slate-300 hover:text-cyan-glow dark:text-slate-300 dark:hover:text-cyan-glow transition-colors duration-200"
              >
                {link.name}
              </a>
            ))}

            {/* Dark/Light mode selector */}
            <button
              onClick={toggleTheme}
              className="p-2 rounded-full bg-slate-800 dark:bg-slate-800 text-slate-300 hover:text-cyan-glow transition-all hover:scale-110 border border-white/10"
              aria-label="Toggle theme"
              id="theme-toggle"
            >
              {isDarkMode ? <Sun className="w-4 h-4 text-amber-400 animate-spin-slow" /> : <Moon className="w-4 h-4 text-violet-400" />}
            </button>
          </nav>

          {/* Mobile Actions block */}
          <div className="flex items-center gap-4 md:hidden">
            <button
              onClick={toggleTheme}
              className="p-1.5 rounded-full bg-slate-800 text-slate-300 hover:text-cyan-glow transition-all border border-white/10"
              aria-label="Toggle theme"
              id="mobile-theme-toggle"
            >
              {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-violet-400" />}
            </button>

            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-1.5 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-all border border-white/10"
              aria-label="Toggle main menu"
              id="mobile-menu-btn"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {isMobileMenuOpen && (
        <div
          className="md:hidden bg-slate-900/95 dark:bg-slate-950/98 backdrop-blur-lg border-b border-white/10 px-4 pt-2 pb-6 space-y-3"
          id="mobile-nav-drawer"
        >
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={() => setIsMobileMenuOpen(false)}
              className="block px-3 py-2.5 rounded-md text-base font-medium text-slate-300 hover:text-cyan-glow hover:bg-slate-800/50 transition-all"
            >
              {link.name}
            </a>
          ))}
        </div>
      )}
    </header>
  );
}
