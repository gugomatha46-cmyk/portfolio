# ⚡ GOMATHA PRIYAN G - Personal Portfolio Website

Welcome to the official source code for **Gomatha Priyan G's** personal portfolio. Designed with a premium, sleek dark cybernetic theme utilizing cutting-edge frontend structures, responsive interfaces, and interactive glassmorphism designs.

## 🌟 Visual Theme
*   **Primary Accent:** `#00F5FF` (Neon Cyan Glow)
*   **Secondary Accent:** `#7B2FF7` (Electric Purple Glow)
*   **Highlight Tint:** `#00C9A7` (Teal Glow)
*   **Deep Canvas:** `#0f172a` (Deep Slate Dark Theme)
*   **Typography:** [Poppins](https://fonts.google.com/specimen/Poppins) & [JetBrains Mono](https://fonts.google.com/specimen/JetBrains+Mono)

---

## 🎨 Key Features & Modules
1.  **Immersive Hero Block:** Includes a custom high-quality AI/Data Science illustration avatar, interactive social badges, and an animated, custom-paced typing carousel cycling through key skills.
2.  **About Me Module:** Includes a code mockup console that visually displays Gomatha's developer profile as a raw JSON dictionary, flanked by core engineering pillars.
3.  **Academic Vertical Timeline:** Displays educational paths with dynamic vertical rails and icon markers (B.Tech at J.N.N Institute of Engineering).
4.  **Skills Engine:** Employs animated circular progress wheels for core subjects (Java, AI, Web Dev) alongside interactive linear bar indicators grouped by filters (Programming, Tools, Technologies).
5.  **Project Showroom:** Incorporates full category tabs (All, Java, Web, AI) and beautiful card outlines. Clicking on any card opens a fully functional details modal detailing technologies used, descriptions, and action triggers.
6.  **Currently Learning Section:** Outlines current training, studies, and open-source explorations with beautiful status badges.
7.  **Achievements Counters:** Dynamically counts numbers from 0 up to target metrics (Coding Hours, GitHub Commits) when scrolled into view.
8.  **Future Goals Grid:** Highlights vision cards mapped with progress status widgets (Completed, In Progress, Upcoming).
9.  **Interactive Connect Form:** Features a fully client-validated contact form with built-in submission delay emulation, success dialogs, and maps.
10. **Aesthetic Enhancements:** Implements custom mouse-trail custom cursors, smooth scroll progression bar, canvas background particles, and a fully functional Dark / Light theme toggle.

---

## 🛠️ Project Structure
```text
├── assets/                  # Public resources and icons
│   └── images/              # Profile illustrations and project cards
├── src/
│   ├── components/          # High-performance modular sections
│   │   ├── About.tsx        # Profile definitions and JSON Console
│   │   ├── Achievements.tsx # Metric counter grids
│   │   ├── Contact.tsx      # Form handlers and response dialogs
│   │   ├── CustomCursor.tsx # Fixed custom cursor ring followers
│   │   ├── Experience.tsx   # "Currently Learning" panels
│   │   ├── Footer.tsx       # Back-to-top button
│   │   ├── FutureGoals.tsx  # Vision milestones
│   │   ├── Header.tsx       # Navigation bar with scroll-bar & theme toggles
│   │   ├── Hero.tsx         # Typing effect and avatar grids
│   │   ├── ParticlesBg.tsx  # Ambient floating background particles
│   │   ├── Projects.tsx     # Project listings with filter & modal readouts
│   │   └── ShowcaseExtra.tsx# GitHub charts, testimonials & certs
│   ├── data.ts              # Global content definitions and configuration
│   ├── types.ts             # Strict TypeScript models
│   ├── App.tsx              # Coordinator and State master
│   ├── index.css            # Tailwind configurations, custom keyframes & scrollbars
│   └── main.tsx             # DOM mounting entry
├── index.html               # Main index with premium SEO and Open Graph metadata
├── package.json             # NPM dependencies & scripts
└── vite.config.ts           # Bundler config
```

---

## 🚀 Setup & Installation

### Prerequisites
Make sure you have [Node.js](https://nodejs.org/) installed on your machine.

### 1. Install Dependencies
Run the installation script to fetch required libraries:
```bash
npm install
```

### 2. Launch Local Development Server
Boot up the fast local development server:
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your web browser to view the application.

### 3. Build Production-ready Static Code
Compile the application into static files:
```bash
npm run build
```
This produces a compiled, optimized, and static bundle inside the `dist/` folder.

---

## 📁 GitHub Pages Deployment Guide

To deploy this React + Vite portfolio website on GitHub Pages:

### Step 1: Install the GitHub Pages Deployment Utility
```bash
npm install gh-pages --save-dev
```

### Step 2: Configure `vite.config.ts` base path
Ensure your base path in `vite.config.ts` matches your repository name (e.g., `base: '/repository-name/'`). If deploying to a custom domain, use `base: '/'`.

### Step 3: Configure package.json Scripts
Add these scripts inside your `"scripts"` block in `package.json`:
```json
"predeploy": "npm run build",
"deploy": "gh-pages -p dist"
```

### Step 4: Run the Deploy Script
```bash
npm run deploy
```
This will automatically build your site and push the compiled contents of the `dist/` folder to the `gh-pages` branch on your GitHub repository, making your site live instantly!

---

## ⚙️ Customization Guide

All personal credentials, portfolio items, certifications, and links are kept in a single file to make customization extremely easy:

*   Open **`src/data.ts`**.
*   Modify `personalDetails` with your own details, social profiles, and resume link.
*   Update `educationTimeline`, `skills`, `projects`, `learningItems`, `achievements`, and `futureGoals` arrays to reflect your own journey!
*   The application will automatically adapt to your custom data on build!

---

## 📄 License
This project is licensed under the Apache-2.0 License. Feel free to use and adapt this portfolio to showcase your own amazing work.

*Made with ❤️ by Gomatha Priyan G.*
