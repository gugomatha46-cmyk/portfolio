export interface Project {
  id: string;
  title: string;
  category: 'java' | 'web' | 'ai' | 'all';
  description: string;
  longDescription?: string;
  technologies: string[];
  githubUrl: string;
  liveUrl: string;
  imageUrl: string;
}

export interface Education {
  id: string;
  degree: string;
  field: string;
  institution: string;
  period: string;
  description: string;
  grade?: string;
}

export interface Skill {
  name: string;
  level: number; // percentage 0-100
  category: 'programming' | 'tools' | 'technologies';
}

export interface Achievement {
  label: string;
  value: number;
  suffix: string;
  icon: string;
}

export interface Goal {
  title: string;
  description: string;
  status: 'pending' | 'in-progress' | 'completed';
}

export interface LearningItem {
  topic: string;
  level: string;
  description: string;
}

export interface Testimonial {
  name: string;
  role: string;
  text: string;
  avatar: string;
}

export interface Certificate {
  title: string;
  issuer: string;
  date: string;
  credentialUrl?: string;
  imageUrl?: string;
}
