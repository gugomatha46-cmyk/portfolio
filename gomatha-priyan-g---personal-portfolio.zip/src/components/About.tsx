import { motion } from 'motion/react';
import { User, Terminal, Code2, Brain, Compass, HelpCircle } from 'lucide-react';
import { personalDetails } from '../data';

export default function About() {
  const values = [
    {
      icon: <Terminal className="w-5 h-5 text-cyan-glow" />,
      title: "Clean Developer",
      desc: "Writing structured, logical, and robust code adhering to OOP best practices."
    },
    {
      icon: <Brain className="w-5 h-5 text-purple-glow" />,
      title: "AI & ML Enthusiast",
      desc: "Eagerly exploring prediction models, analytics pipelines, and neural networks."
    },
    {
      icon: <Code2 className="w-5 h-5 text-teal-glow" />,
      title: "Modern Web Craft",
      desc: "Creating pixel-perfect, lightning-fast client interfaces with sleek responsiveness."
    }
  ];

  return (
    <section id="about" className="py-24 bg-slate-950 relative overflow-hidden">
      {/* Background radial gradient accent */}
      <div className="absolute right-0 top-1/4 w-96 h-96 bg-purple-glow/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800 border border-white/5 text-xs font-semibold text-purple-glow tracking-wider uppercase mb-3"
          >
            <User className="w-3.5 h-3.5" />
            <span>Overview</span>
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-3xl sm:text-4xl font-bold tracking-tight text-white"
          >
            About <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-glow to-teal-glow">Me</span>
          </motion.h2>
          <motion.div
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="h-1 w-20 bg-gradient-to-r from-cyan-glow to-teal-glow mx-auto mt-4 rounded-full origin-left"
          />
        </div>

        {/* Core Layout - Centered Professional Narrative */}
        <div className="max-w-4xl mx-auto">
          
          <motion.div
            className="space-y-8 text-center"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8 }}
          >
            <h3 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
              Crafting solutions at the intersection of <span className="text-purple-glow">Code</span> and <span className="text-cyan-glow">Intelligence</span>.
            </h3>

            <p className="text-slate-400 leading-relaxed text-base sm:text-lg max-w-3xl mx-auto">
              {personalDetails.bio}
            </p>

            <p className="text-slate-400 leading-relaxed text-base max-w-3xl mx-auto">
              Currently studying Artificial Intelligence and Data Science, I focus on unlocking patterns from data and developing scalable client-side systems. I aim to continuously build, deploy, and refine software that empowers communities and solves industry hurdles.
            </p>

            {/* Quick Micro-Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-6">
              {values.map((v, idx) => (
                <div
                  key={idx}
                  className="p-5 rounded-xl glass-card border border-white/5 hover:border-white/15 hover:bg-slate-900/60 transition-all duration-300 glow-border-purple text-center flex flex-col items-center"
                >
                  <div className="mb-4 p-2.5 w-max rounded-lg bg-slate-800 border border-white/5">
                    {v.icon}
                  </div>
                  <h4 className="font-semibold text-white text-base mb-2">{v.title}</h4>
                  <p className="text-xs text-slate-400 leading-relaxed">{v.desc}</p>
                </div>
              ))}
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
