import { useState, useEffect, useRef } from 'react';
import { motion, useInView } from 'motion/react';
import { CheckCircle, Code, Clock, GitCommit, Trophy } from 'lucide-react';
import { achievements } from '../data';

// Custom lightweight Counter Component
function AnimatedCounter({ value, duration = 1500 }: { value: number; duration?: number }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement | null>(null);
  const isInView = useInView(ref, { once: true, margin: '-50px' });

  useEffect(() => {
    if (!isInView) return;

    let start = 0;
    const end = value;
    if (start === end) return;

    const totalMiliseconds = duration;
    const incrementTime = Math.max(Math.floor(totalMiliseconds / end), 15);
    
    const timer = setInterval(() => {
      start += 1;
      setCount(start);
      if (start === end) {
        clearInterval(timer);
      }
    }, incrementTime);

    return () => clearInterval(timer);
  }, [value, duration, isInView]);

  return <span ref={ref}>{count}</span>;
}

export default function Achievements() {
  // Mapping names to actual Lucide components dynamically
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'CheckCircle':
        return <CheckCircle className="w-6 h-6 text-cyan-glow" />;
      case 'Code':
        return <Code className="w-6 h-6 text-purple-glow" />;
      case 'Clock':
        return <Clock className="w-6 h-6 text-teal-glow" />;
      case 'GitCommit':
        return <GitCommit className="w-6 h-6 text-cyan-glow" />;
      default:
        return <Trophy className="w-6 h-6 text-purple-glow" />;
    }
  };

  return (
    <section className="py-20 bg-slate-900 relative overflow-hidden">
      {/* Centered background neon leak */}
      <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-cyan-glow/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Metric Cards Layout */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8 max-w-5xl mx-auto">
          {achievements.map((item, idx) => (
            <motion.div
              key={item.label}
              className="glass-card rounded-2xl p-6 sm:p-8 border border-white/5 text-center flex flex-col items-center justify-center shadow-xl hover:bg-slate-850/60 hover:border-cyan-glow/20 transition-all duration-300 relative overflow-hidden group"
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
            >
              {/* Spinning background outline aura on hover */}
              <div className="absolute -inset-10 bg-gradient-to-r from-purple-glow via-cyan-glow to-teal-glow rounded-full blur-2xl opacity-0 group-hover:opacity-10 transition-opacity duration-500" />

              {/* Icon */}
              <div className="mb-4 p-3 rounded-2xl bg-slate-950/60 border border-white/5 group-hover:scale-110 transition-transform">
                {getIcon(item.icon)}
              </div>

              {/* Counting stat value */}
              <div className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight font-mono mb-1.5 flex items-center justify-center">
                <AnimatedCounter value={item.value} />
                <span className="text-cyan-glow">{item.suffix}</span>
              </div>

              {/* Title label */}
              <p className="text-xs sm:text-sm font-semibold text-slate-400 uppercase tracking-widest font-sans">
                {item.label}
              </p>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
