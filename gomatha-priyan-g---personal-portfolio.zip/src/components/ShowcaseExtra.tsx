import { useState } from 'react';
import { motion } from 'motion/react';
import { Award, MessageSquare, Github, Newspaper, ArrowUpRight, Heart, Star, Quote } from 'lucide-react';
import { certificates, testimonials, personalDetails } from '../data';

export default function ShowcaseExtra() {
  const [activeTestimonial, setActiveTestimonial] = useState(0);

  // Mock data for the Git Grid (14 columns x 7 rows to represent recent contribution activity)
  const daysInGraph = Array.from({ length: 98 }, (_, i) => {
    const weights = [0, 0, 0, 1, 1, 0, 0, 2, 2, 0, 3, 0, 1, 4, 0, 0, 2, 1, 3, 0, 0];
    return weights[Math.floor(Math.sin(i * 1.5) * 10 + 10) % weights.length];
  });

  const getIntensityColor = (intensity: number) => {
    switch (intensity) {
      case 1: return 'bg-emerald-950/40 border border-emerald-900/40';
      case 2: return 'bg-emerald-800/60 border border-emerald-700/40';
      case 3: return 'bg-emerald-600/80 border border-emerald-500/40';
      case 4: return 'bg-cyan-glow border border-cyan-glow/50 shadow-[0_0_8px_rgba(0,245,255,0.4)]';
      default: return 'bg-slate-900 border border-white/5';
    }
  };

  const blogPosts = [
    {
      title: "Mastering Java Object-Oriented Principles",
      desc: "An in-depth handbook covering polymorphism, dynamic binding, and solid architecture patterns for student developers.",
      date: "June 2026",
      readTime: "5 min read",
      likes: 42
    },
    {
      title: "My First Steps in Artificial Intelligence",
      desc: "Explaining regressions, data normalization models, and building simple predict systems with python-based scikit tools.",
      date: "May 2026",
      readTime: "7 min read",
      likes: 58
    }
  ];

  return (
    <section className="py-24 bg-slate-900 relative overflow-hidden" id="showcase-extra">
      <div className="absolute right-0 top-0 w-80 h-80 bg-teal-glow/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-white">
            Endorsements & <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-glow to-cyan-glow">Credentials</span>
          </h2>
          <div className="h-1 w-20 bg-gradient-to-r from-teal-glow to-cyan-glow mx-auto mt-4 rounded-full" />
        </div>

        {/* Dual Grid Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          
          {/* Left Column: Certifications & Blog (7 cols) */}
          <div className="lg:col-span-7 space-y-12">
            
            {/* Certifications Card Module */}
            <motion.div
              className="glass-card rounded-2xl p-6 border border-white/5"
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.6 }}
            >
              <div className="flex items-center gap-2.5 mb-6">
                <div className="p-2 rounded-lg bg-slate-950/60 border border-white/5 text-cyan-glow">
                  <Award className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-white">Earned Certifications</h3>
              </div>

              <div className="space-y-4">
                {certificates.map((cert) => (
                  <div
                    key={cert.title}
                    className="p-4 rounded-xl bg-slate-950/40 border border-white/5 hover:border-cyan-glow/20 transition-all duration-300 flex items-center justify-between group"
                  >
                    <div>
                      <h4 className="font-bold text-white text-sm sm:text-base group-hover:text-cyan-glow transition-colors">
                        {cert.title}
                      </h4>
                      <p className="text-xs text-slate-400 mt-1">
                        {cert.issuer} • <span className="text-purple-glow">{cert.date}</span>
                      </p>
                    </div>
                    
                    <a
                      href={cert.credentialUrl}
                      className="p-1.5 rounded-lg bg-slate-900 border border-white/5 text-slate-400 hover:text-white hover:border-cyan-glow/30 transition-all"
                      aria-label="View credential"
                    >
                      <ArrowUpRight className="w-4 h-4" />
                    </a>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* GitHub Contribution Graph representation */}
            <motion.div
              className="glass-card rounded-2xl p-6 border border-white/5 overflow-hidden"
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.6, delay: 0.15 }}
            >
              <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-lg bg-slate-950/60 border border-white/5 text-cyan-glow">
                    <Github className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white leading-none">GitHub Contribution Flow</h3>
                    <span className="text-[10px] text-slate-500 font-mono mt-1 block">gomathapriyang / profile</span>
                  </div>
                </div>
                
                <a
                  href={personalDetails.github}
                  target="_blank"
                  rel="noreferrer"
                  className="text-xs font-mono text-cyan-glow hover:underline inline-flex items-center gap-1"
                >
                  <span>@gomathapriyang</span>
                  <ArrowUpRight className="w-3 h-3" />
                </a>
              </div>

              {/* Grid drawing */}
              <div className="bg-slate-950/80 p-4 rounded-xl border border-white/5 overflow-x-auto">
                <div className="flex gap-1.5 min-w-[340px] justify-between">
                  <div className="grid grid-flow-col grid-rows-7 gap-1">
                    {daysInGraph.map((intensity, i) => (
                      <div
                        key={i}
                        className={`w-3.5 h-3.5 rounded-[2px] transition-colors duration-300 hover:scale-115 cursor-pointer ${getIntensityColor(intensity)}`}
                        title={`${intensity} contributions`}
                      />
                    ))}
                  </div>
                </div>
                {/* Legend */}
                <div className="flex items-center justify-end gap-1.5 mt-3 text-[10px] text-slate-500 font-mono">
                  <span>Less</span>
                  <div className="w-2.5 h-2.5 rounded-[2px] bg-slate-900 border border-white/5" />
                  <div className="w-2.5 h-2.5 rounded-[2px] bg-emerald-950" />
                  <div className="w-2.5 h-2.5 rounded-[2px] bg-emerald-800" />
                  <div className="w-2.5 h-2.5 rounded-[2px] bg-emerald-600" />
                  <div className="w-2.5 h-2.5 rounded-[2px] bg-cyan-glow" />
                  <span>More</span>
                </div>
              </div>
            </motion.div>

          </div>

          {/* Right Column: Recommendations & Logs (5 cols) */}
          <div className="lg:col-span-5 space-y-12">
            
            {/* Testimonial slider / showcase */}
            <motion.div
              className="glass-card rounded-2xl p-6 border border-white/5 relative flex flex-col justify-between"
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.6 }}
            >
              <div className="flex items-center gap-2.5 mb-6">
                <div className="p-2 rounded-lg bg-slate-950/60 border border-white/5 text-cyan-glow">
                  <MessageSquare className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-white">Academic Endorsements</h3>
              </div>

              {/* Active testimonial container */}
              <div className="space-y-6 min-h-48 relative">
                <Quote className="absolute -top-3 -left-2 w-10 h-10 text-cyan-glow/10" />
                
                <p className="text-xs sm:text-sm text-slate-300 italic leading-relaxed pl-6 relative z-10">
                  "{testimonials[activeTestimonial].text}"
                </p>

                <div className="flex items-center gap-3 pt-4 border-t border-slate-800/60 pl-6">
                  <img
                    src={testimonials[activeTestimonial].avatar}
                    alt={testimonials[activeTestimonial].name}
                    className="w-10 h-10 rounded-full object-cover border border-cyan-glow/20"
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <h4 className="font-bold text-white text-xs sm:text-sm">{testimonials[activeTestimonial].name}</h4>
                    <p className="text-[10px] text-slate-500 font-medium">{testimonials[activeTestimonial].role}</p>
                  </div>
                </div>
              </div>

              {/* Slider Dots */}
              <div className="flex items-center justify-center gap-2 mt-6">
                {testimonials.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveTestimonial(i)}
                    className={`h-1.5 rounded-full transition-all ${
                      activeTestimonial === i ? 'w-5 bg-cyan-glow' : 'w-1.5 bg-slate-700 hover:bg-slate-600'
                    }`}
                    aria-label={`Slide to testimonial ${i + 1}`}
                  />
                ))}
              </div>
            </motion.div>

            {/* Latest reading log / Blog placeholder */}
            <motion.div
              className="glass-card rounded-2xl p-6 border border-white/5"
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.6, delay: 0.15 }}
            >
              <div className="flex items-center gap-2.5 mb-6">
                <div className="p-2 rounded-lg bg-slate-950/60 border border-white/5 text-cyan-glow">
                  <Newspaper className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-white">Latest Technology Logs</h3>
              </div>

              <div className="space-y-4">
                {blogPosts.map((post) => (
                  <div
                    key={post.title}
                    className="p-4 rounded-xl bg-slate-950/40 border border-white/5 hover:border-cyan-glow/20 transition-all duration-300 relative group cursor-pointer"
                  >
                    <div className="flex justify-between items-start mb-2">
                      <span className="text-[10px] font-mono text-cyan-glow">{post.date}</span>
                      <span className="text-[10px] font-mono text-slate-500">{post.readTime}</span>
                    </div>

                    <h4 className="font-bold text-white text-xs sm:text-sm group-hover:text-cyan-glow transition-colors leading-tight mb-1.5">
                      {post.title}
                    </h4>
                    
                    <p className="text-[11px] text-slate-400 leading-relaxed mb-3 line-clamp-2">
                      {post.desc}
                    </p>

                    <div className="flex items-center gap-3 text-[10px] text-slate-500 font-mono">
                      <span className="flex items-center gap-1 hover:text-red-400 transition-colors">
                        <Heart className="w-3.5 h-3.5" />
                        <span>{post.likes} likes</span>
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

          </div>

        </div>

      </div>
    </section>
  );
}
