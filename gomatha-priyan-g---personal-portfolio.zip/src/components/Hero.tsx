import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Github, Linkedin, Mail, FileText, ArrowRight, ArrowDown } from 'lucide-react';
import { personalDetails } from '../data';

// Custom lightweight Typing Effect Component
function TypingEffect({ strings, period = 1500 }: { strings: string[]; period?: number }) {
  const [currentWordIdx, setCurrentWordIdx] = useState(0);
  const [currentText, setCurrentText] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);
  const [typingSpeed, setTypingSpeed] = useState(100);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    const fullWord = strings[currentWordIdx];

    const handleType = () => {
      if (!isDeleting) {
        // Add character
        setCurrentText(fullWord.substring(0, currentText.length + 1));
        setTypingSpeed(90 - Math.random() * 40); // natural pace

        if (currentText === fullWord) {
          // Pause before deleting
          timer = setTimeout(() => {
            setIsDeleting(true);
          }, period);
          return;
        }
      } else {
        // Remove character
        setCurrentText(fullWord.substring(0, currentText.length - 1));
        setTypingSpeed(40);

        if (currentText === '') {
          setIsDeleting(false);
          setCurrentWordIdx((prev) => (prev + 1) % strings.length);
          setTypingSpeed(400); // delay before starting next word
        }
      }

      timer = setTimeout(handleType, typingSpeed);
    };

    timer = setTimeout(handleType, typingSpeed);
    return () => clearTimeout(timer);
  }, [currentText, isDeleting, currentWordIdx, strings, period, typingSpeed]);

  return (
    <span className="relative">
      <span className="text-cyan-glow border-r-2 border-cyan-glow pr-1 animate-pulse font-mono">
        {currentText}
      </span>
    </span>
  );
}

export default function Hero() {
  const words = [
    'Java Developer',
    'AI Enthusiast',
    'Web Developer',
    'Future Tech Explorer',
    'Student'
  ];

  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center justify-center pt-24 pb-16 overflow-hidden bg-slate-900 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(123,47,247,0.15),rgba(255,255,255,0))]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Hero Left Content */}
          <motion.div
            className="lg:col-span-7 space-y-6 text-center lg:text-left"
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass-card border border-cyan-glow/20 text-xs font-semibold text-cyan-glow tracking-wide animate-bounce">
              <span className="w-2 h-2 rounded-full bg-cyan-glow animate-ping" />
              {personalDetails.college} • {personalDetails.year}
            </div>

            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight text-white leading-tight">
              Hi, I'm <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-glow via-purple-glow to-teal-glow filter drop-shadow-md">
                {personalDetails.name}
              </span>
            </h1>

            <div className="text-xl sm:text-2xl font-medium text-slate-300 h-12 flex items-center justify-center lg:justify-start">
              <span>I am a&nbsp;</span>
              <TypingEffect strings={words} />
            </div>

            <p className="text-base sm:text-lg text-slate-400 max-w-2xl mx-auto lg:mx-0 leading-relaxed font-sans">
              {personalDetails.objective}
            </p>

            {/* Call To Action Buttons */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-4">
              <a
                href="#projects"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full font-medium text-white bg-gradient-to-r from-purple-glow to-cyan-glow hover:brightness-115 transition-all shadow-[0_4px_20px_rgba(123,47,247,0.3)] hover:scale-105"
              >
                <span>View Projects</span>
                <ArrowRight className="w-4 h-4" />
              </a>

              <a
                href="#contact"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full font-medium text-slate-300 hover:text-white glass-card border border-white/10 hover:border-cyan-glow/50 transition-all hover:scale-105"
              >
                <FileText className="w-4 h-4" />
                <span>Download Resume</span>
              </a>
            </div>

            {/* Quick Social Contacts */}
            <div className="flex items-center justify-center lg:justify-start gap-5 pt-6 border-t border-slate-800/60 max-w-sm mx-auto lg:mx-0">
              <span className="text-xs text-slate-500 uppercase tracking-widest font-mono">Connect</span>
              
              <a
                href={personalDetails.github}
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-full bg-slate-800/40 border border-white/5 text-slate-400 hover:text-cyan-glow hover:border-cyan-glow/40 hover:scale-110 transition-all"
                aria-label="GitHub Profile"
              >
                <Github className="w-5 h-5" />
              </a>

              <a
                href={personalDetails.linkedin}
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-full bg-slate-800/40 border border-white/5 text-slate-400 hover:text-purple-glow hover:border-purple-glow/40 hover:scale-110 transition-all"
                aria-label="LinkedIn Profile"
              >
                <Linkedin className="w-5 h-5" />
              </a>

              <a
                href={`mailto:${personalDetails.email}`}
                className="p-2 rounded-full bg-slate-800/40 border border-white/5 text-slate-400 hover:text-teal-glow hover:border-teal-glow/40 hover:scale-110 transition-all"
                aria-label="Email Gomatha"
              >
                <Mail className="w-5 h-5" />
              </a>
            </div>
          </motion.div>

          {/* Hero Right Avatar (Glassmorphism Layout) */}
          <motion.div
            className="lg:col-span-5 flex justify-center items-center"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.2, ease: 'easeOut' }}
          >
            <div className="relative w-72 h-72 sm:w-85 sm:h-85 lg:w-96 lg:h-96 group">
              {/* Outer decorative ambient glows */}
              <div className="absolute -inset-4 bg-gradient-to-tr from-purple-glow via-cyan-glow to-teal-glow rounded-full blur-2xl opacity-35 group-hover:opacity-50 transition-opacity duration-500 animate-pulse-slow" />
              
              {/* Rotating glowing orbits */}
              <div className="absolute inset-0 rounded-full border border-dashed border-cyan-glow/20 animate-orbit-slow" />
              <div className="absolute -inset-6 rounded-full border border-dashed border-purple-glow/10 animate-orbit-medium" />

              {/* Main Avatar Container */}
              <div className="absolute inset-0 rounded-3xl overflow-hidden glass-card p-3 border border-white/10 group-hover:border-cyan-glow/30 transition-colors duration-500 shadow-2xl">
                <div className="relative w-full h-full rounded-2xl overflow-hidden bg-slate-950">
                  <img
                    src="/src/assets/images/profile_avatar_1783660506514.jpg"
                    alt="Gomatha Priyan G Profile Avatar"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                  
                  {/* Subtle Tech overlay graphics */}
                  <div className="absolute bottom-4 left-4 right-4 glass-card p-3 rounded-xl border border-white/5 text-center">
                    <span className="block text-xs font-semibold text-cyan-glow tracking-wider uppercase font-mono">
                      Artificial Intelligence Student
                    </span>
                    <span className="block text-[10px] text-slate-500 mt-0.5">
                      J.N.N Institute of Engineering
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Floating Scroll Indicator */}
      <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex flex-col items-center gap-1 opacity-70 hover:opacity-100 transition-opacity">
        <span className="text-[10px] font-mono tracking-widest text-slate-500 uppercase">Scroll Down</span>
        <a href="#about" className="p-2 rounded-full bg-slate-800/40 text-cyan-glow border border-white/5 hover:border-cyan-glow/30 hover:scale-110 transition-all animate-bounce">
          <ArrowDown className="w-4 h-4" />
        </a>
      </div>
    </section>
  );
}
