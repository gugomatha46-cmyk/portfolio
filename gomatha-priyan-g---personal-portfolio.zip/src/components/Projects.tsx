import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { FolderGit2, Github, ExternalLink, X, Compass, Filter } from 'lucide-react';
import { projects } from '../data';
import { Project } from '../types';

export default function Projects() {
  const [activeCategory, setActiveCategory] = useState<'all' | 'java' | 'web' | 'ai'>('all');
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  const categories = [
    { id: 'all', name: 'All Work' },
    { id: 'java', name: 'Java OOP' },
    { id: 'web', name: 'Web Dev' },
    { id: 'ai', name: 'AI & Data Science' }
  ];

  const filteredProjects = activeCategory === 'all'
    ? projects
    : projects.filter(p => p.category === activeCategory);

  return (
    <section id="projects" className="py-24 bg-slate-900 relative overflow-hidden">
      {/* Decorative gradient overlay */}
      <div className="absolute left-1/4 top-1/4 w-80 h-80 bg-purple-glow/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800 border border-white/5 text-xs font-semibold text-purple-glow tracking-wider uppercase mb-3"
          >
            <FolderGit2 className="w-3.5 h-3.5" />
            <span>Showcase</span>
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-3xl sm:text-4xl font-bold tracking-tight text-white"
          >
            Innovative <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-glow to-cyan-glow">Projects</span>
          </motion.h2>
          <motion.div
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="h-1 w-20 bg-gradient-to-r from-purple-glow to-cyan-glow mx-auto mt-4 rounded-full origin-left"
          />
        </div>

        {/* Project Filter Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 mb-12">
          <div className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-slate-950/40 border border-white/5 mr-2 text-xs text-slate-400 font-mono">
            <Filter className="w-3.5 h-3.5 text-cyan-glow" />
            <span>Filter:</span>
          </div>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id as any)}
              className={`px-4.5 py-1.5 rounded-full text-xs font-semibold tracking-wider transition-all duration-200 border ${
                activeCategory === cat.id
                  ? 'bg-gradient-to-r from-purple-glow to-cyan-glow text-white border-transparent shadow-lg shadow-purple-glow/20'
                  : 'bg-slate-950/40 text-slate-400 border-white/5 hover:text-white hover:border-white/15'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>

        {/* Project Cards Grid */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto"
          layout
        >
          <AnimatePresence mode="popLayout">
            {filteredProjects.map((project, index) => (
              <motion.div
                key={project.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
                className="glass-card rounded-2xl overflow-hidden border border-white/5 hover:border-cyan-glow/25 transition-all duration-300 group flex flex-col h-full shadow-lg glow-border-cyan cursor-pointer"
                onClick={() => setSelectedProject(project)}
              >
                {/* Card Header Image Mockup */}
                <div className="relative aspect-video w-full overflow-hidden bg-slate-950">
                  <div className="absolute inset-0 bg-slate-950/40 z-10 transition-opacity group-hover:opacity-10" />
                  <img
                    src={project.imageUrl}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  
                  {/* Category overlay label */}
                  <span className="absolute top-4 left-4 z-20 px-3 py-1 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider text-white bg-slate-950/80 border border-white/10 backdrop-blur-sm">
                    {project.category}
                  </span>
                </div>

                {/* Card Body Content */}
                <div className="p-6 flex flex-col flex-grow">
                  <h3 className="text-xl font-bold text-white group-hover:text-cyan-glow transition-colors font-sans mb-2">
                    {project.title}
                  </h3>
                  
                  <p className="text-xs sm:text-sm text-slate-400 leading-relaxed flex-grow">
                    {project.description}
                  </p>

                  {/* Technology chips */}
                  <div className="flex flex-wrap items-center gap-1.5 mt-4 pt-4 border-t border-slate-800/60">
                    {project.technologies.slice(0, 3).map((tech) => (
                      <span
                        key={tech}
                        className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-950/40 border border-white/5 text-slate-400"
                      >
                        {tech}
                      </span>
                    ))}
                    {project.technologies.length > 3 && (
                      <span className="text-[9px] font-mono text-cyan-glow px-1.5">
                        +{project.technologies.length - 3} more
                      </span>
                    )}
                  </div>

                  {/* Footer action buttons */}
                  <div className="flex items-center gap-3 mt-5" onClick={(e) => e.stopPropagation()}>
                    <a
                      href={project.githubUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="flex-1 inline-flex items-center justify-center gap-2 py-2 px-3.5 rounded-lg text-xs font-semibold text-slate-300 bg-slate-950/60 hover:text-white hover:bg-slate-950 border border-white/5 hover:border-cyan-glow/40 transition-all"
                    >
                      <Github className="w-3.5 h-3.5" />
                      <span>Code</span>
                    </a>
                    <a
                      href={project.liveUrl}
                      className="flex-1 inline-flex items-center justify-center gap-2 py-2 px-3.5 rounded-lg text-xs font-semibold text-white bg-gradient-to-r from-purple-glow to-cyan-glow hover:brightness-110 shadow-md transition-all"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Live Demo</span>
                    </a>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {/* Dynamic Project Details Modal Overlay */}
        <AnimatePresence>
          {selectedProject && (
            <motion.div
              className="fixed inset-0 z-50 flex items-center justify-center px-4 py-8 bg-slate-950/80 backdrop-blur-md"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedProject(null)}
            >
              <motion.div
                className="glass-card max-w-2xl w-full rounded-2xl border border-white/15 overflow-hidden shadow-2xl relative flex flex-col max-h-[90vh] text-left"
                initial={{ scale: 0.9, y: 30, opacity: 0 }}
                animate={{ scale: 1, y: 0, opacity: 1 }}
                exit={{ scale: 0.9, y: 30, opacity: 0 }}
                transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                onClick={(e) => e.stopPropagation()}
              >
                {/* Close Button */}
                <button
                  onClick={() => setSelectedProject(null)}
                  className="absolute top-4 right-4 z-30 p-2 rounded-full bg-slate-950/80 hover:bg-slate-900 border border-white/10 text-slate-300 hover:text-white transition-all hover:rotate-90"
                  aria-label="Close details"
                >
                  <X className="w-4 h-4" />
                </button>

                {/* Hero Banner Image */}
                <div className="relative aspect-video w-full overflow-hidden bg-slate-950 shrink-0">
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent z-10" />
                  <img
                    src={selectedProject.imageUrl}
                    alt={selectedProject.title}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <span className="absolute bottom-4 left-6 z-20 px-3 py-1 rounded-full text-xs font-mono font-bold uppercase tracking-wider text-white bg-purple-glow/80 border border-white/10 backdrop-blur-sm">
                    {selectedProject.category}
                  </span>
                </div>

                {/* Body Content (Scrollable) */}
                <div className="p-6 overflow-y-auto space-y-4">
                  <h3 className="text-2xl font-bold text-white tracking-tight">
                    {selectedProject.title}
                  </h3>

                  <p className="text-sm text-slate-300 leading-relaxed">
                    {selectedProject.longDescription || selectedProject.description}
                  </p>

                  {/* Technology Tags */}
                  <div>
                    <h4 className="text-xs font-mono uppercase tracking-widest text-slate-500 mb-2 font-semibold">
                      Technologies Employed
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedProject.technologies.map((tech) => (
                        <span
                          key={tech}
                          className="text-xs font-mono px-3 py-1 rounded-full bg-slate-950/80 border border-white/5 text-cyan-glow"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Modal Footer Links */}
                  <div className="flex items-center gap-4 pt-4 border-t border-slate-800/60 shrink-0">
                    <a
                      href={selectedProject.githubUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="flex-1 inline-flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-sm font-semibold text-slate-300 bg-slate-900 hover:text-white hover:bg-slate-950 border border-white/5 hover:border-cyan-glow/45 transition-all"
                    >
                      <Github className="w-4 h-4" />
                      <span>Browse Repository</span>
                    </a>
                    <a
                      href={selectedProject.liveUrl}
                      className="flex-1 inline-flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-sm font-semibold text-white bg-gradient-to-r from-purple-glow to-cyan-glow hover:brightness-110 shadow-lg shadow-purple-glow/10 transition-all"
                    >
                      <ExternalLink className="w-4 h-4" />
                      <span>Launch Applet</span>
                    </a>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </section>
  );
}
