import { useState, useEffect } from 'react';
import { ArrowUp, Heart, Github, Linkedin, Mail, Sparkles } from 'lucide-react';
import { personalDetails } from '../data';

export default function Footer() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const toggleVisibility = () => {
      if (window.scrollY > 400) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener('scroll', toggleVisibility);
    return () => window.removeEventListener('scroll', toggleVisibility);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <footer className="bg-slate-950 border-t border-white/5 py-12 relative overflow-hidden" id="site-footer">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          
          {/* Left Block: Copyright Info */}
          <div className="text-center md:text-left space-y-1">
            <div className="flex items-center justify-center md:justify-start gap-1.5 font-sans font-bold text-lg text-white">
              <Sparkles className="w-4 h-4 text-cyan-glow" />
              <span>GOMATHA PRIYAN G</span>
            </div>
            <p className="text-xs text-slate-500 font-mono">
              &copy; {new Date().getFullYear()} • B.Tech Artificial Intelligence and Data Science Student
            </p>
          </div>

          {/* Middle Block: Loving Credits */}
          <div className="text-xs text-slate-400 flex items-center justify-center gap-1.5 font-sans">
            <span>Made with</span>
            <Heart className="w-3.5 h-3.5 text-red-500 fill-red-500 animate-pulse" />
            <span>by</span>
            <a href="#" className="font-semibold text-transparent bg-clip-text bg-gradient-to-r from-cyan-glow to-teal-glow hover:brightness-110 transition-all">
              {personalDetails.name}
            </a>
          </div>

          {/* Right Block: Social Anchor Buttons */}
          <div className="flex items-center justify-center gap-4">
            <a
              href={personalDetails.github}
              target="_blank"
              rel="noreferrer"
              className="p-2 rounded-full bg-slate-900 border border-white/5 text-slate-400 hover:text-cyan-glow hover:border-cyan-glow/30 transition-all"
              aria-label="GitHub Link"
            >
              <Github className="w-4 h-4" />
            </a>

            <a
              href={personalDetails.linkedin}
              target="_blank"
              rel="noreferrer"
              className="p-2 rounded-full bg-slate-900 border border-white/5 text-slate-400 hover:text-purple-glow hover:border-purple-glow/30 transition-all"
              aria-label="LinkedIn Link"
            >
              <Linkedin className="w-4 h-4" />
            </a>

            <a
              href={`mailto:${personalDetails.email}`}
              className="p-2 rounded-full bg-slate-900 border border-white/5 text-slate-400 hover:text-teal-glow hover:border-teal-glow/30 transition-all"
              aria-label="Email Link"
            >
              <Mail className="w-4 h-4" />
            </a>
          </div>

        </div>
      </div>

      {/* Floating Scroll back-to-top button */}
      {isVisible && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-6 right-6 z-40 p-3 rounded-xl text-slate-900 bg-cyan-glow hover:bg-cyan-glow/85 border border-cyan-glow/30 shadow-[0_4px_16px_rgba(0,245,255,0.4)] transition-all hover:scale-110 animate-bounce cursor-pointer"
          aria-label="Scroll back to top"
          id="back-to-top-btn"
        >
          <ArrowUp className="w-5 h-5 font-bold" />
        </button>
      )}
    </footer>
  );
}
