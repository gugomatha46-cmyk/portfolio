import { Project, Education, Skill, Achievement, Goal, LearningItem, Testimonial, Certificate } from './types';

export const personalDetails = {
  name: "GOMATHA PRIYAN G",
  role: "B.Tech Artificial Intelligence & Data Science Student",
  college: "J.N.N Institute of Engineering",
  year: "Second Year",
  email: "gugomatha46@jnn.edu.in",
  github: "https://github.com", // Fallback / placeholder as requested
  linkedin: "https://linkedin.com", // Fallback / placeholder as requested
  location: "Tamil Nadu, India",
  objective: "Passionate Artificial Intelligence and Data Science student with a strong interest in Java Programming, Web Development, AI Technologies, and Future Technologies. I enjoy learning new technologies, building innovative projects, and continuously improving my development skills.",
  bio: "Hello! I'm Gomatha Priyan G, a second-year B.Tech Artificial Intelligence and Data Science student at J.N.N Institute of Engineering. I have a deep passion for Java programming, modern web development, and emerging technologies. My goal is to become a skilled software developer capable of building innovative AI-powered applications that solve real-world problems.",
  resumeUrl: "#" // Link or placeholder for Resume download
};

export const educationTimeline: Education[] = [
  {
    id: "edu-1",
    degree: "B.Tech (Bachelor of Technology)",
    field: "Artificial Intelligence and Data Science",
    institution: "J.N.N Institute of Engineering",
    period: "2024 - Present (Second Year)",
    description: "Actively studying foundational algorithms, data structures, statistics, programming paradigms, and introductory machine learning concepts. Maintaining a strong academic standing.",
    grade: "Pursuing (Second Year)"
  },
  {
    id: "edu-2",
    degree: "Higher Secondary Certificate (HSC)",
    field: "Computer Science & Mathematics",
    institution: "State Board School",
    period: "2022 - 2024",
    description: "Developed strong foundations in advanced mathematics, physics, and programming basics using C++/Python.",
    grade: "First Class"
  }
];

export const skills: Skill[] = [
  // Programming
  { name: "Java Programming", level: 85, category: "programming" },
  { name: "HTML5", level: 90, category: "programming" },
  { name: "CSS3 / TailwindCSS", level: 85, category: "programming" },
  { name: "JavaScript (ES6+)", level: 80, category: "programming" },
  
  // Tools
  { name: "Git", level: 80, category: "tools" },
  { name: "GitHub", level: 85, category: "tools" },
  { name: "VS Code", level: 90, category: "tools" },
  
  // Technologies
  { name: "Web Development", level: 80, category: "technologies" },
  { name: "Artificial Intelligence", level: 70, category: "technologies" },
  { name: "Machine Learning", level: 65, category: "technologies" },
  { name: "Responsive Design", level: 85, category: "technologies" }
];

export const projects: Project[] = [
  {
    id: "proj-1",
    title: "Personal Portfolio Website",
    category: "web",
    description: "A premium, fully responsive developer portfolio highlighting projects, education timeline, skills, and future goals.",
    longDescription: "Designed and built using React, Vite, and Tailwind CSS. Integrated smooth layout animations, interactive glassmorphic cards, custom floating particles, light/dark modes, and modular structures. Ideal for deployment on GitHub Pages.",
    technologies: ["React", "Vite", "Tailwind CSS", "Motion", "Lucide Icons"],
    githubUrl: "https://github.com",
    liveUrl: "#",
    imageUrl: "https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "proj-2",
    title: "Java Management System",
    category: "java",
    description: "A robust console and graphical application utilizing Java Object-Oriented Programming (OOP) concepts.",
    longDescription: "Developed to demonstrate core Java features including inheritance, interfaces, polymorphism, multithreading, and file I/O operations. Includes database connectivity (JDBC) and a neat dashboard layout.",
    technologies: ["Java", "Swing / JavaFX", "MySQL", "OOP principles"],
    githubUrl: "https://github.com",
    liveUrl: "#",
    imageUrl: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "proj-3",
    title: "AI Mini Project",
    category: "ai",
    description: "An AI-driven predictive analyzer using classification algorithms and dataset preparation tools.",
    longDescription: "A machine learning demonstration project modeling predictive data. Employs Python data-science toolkits to solve classification tasks on local datasets with visualized output metrics.",
    technologies: ["Python", "Scikit-Learn", "Pandas", "Matplotlib"],
    githubUrl: "https://github.com",
    liveUrl: "#",
    imageUrl: "https://images.unsplash.com/photo-1677442136019-21780efad99a?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "proj-4",
    title: "Web Development Project",
    category: "web",
    description: "An interactive, responsive client-side web platform implementing dynamic state management.",
    longDescription: "An exploration into modern client-side frontend architectures, featuring smooth transitions, API-based content streaming, asynchronous operations, and touch-optimized responsive navigation.",
    technologies: ["HTML5", "CSS3", "JavaScript", "Responsive Design", "Fetch API"],
    githubUrl: "https://github.com",
    liveUrl: "#",
    imageUrl: "https://images.unsplash.com/photo-1547658719-da2b51169166?auto=format&fit=crop&w=600&q=80"
  }
];

export const learningItems: LearningItem[] = [
  { topic: "Java Programming", level: "Advanced", description: "Deep diving into advanced Java collections, streams, concurrency, and enterprise frameworks." },
  { topic: "Frontend Development", level: "Intermediate", description: "Mastering React hooks, Tailwind configuration, component design patterns, and SEO optimizations." },
  { topic: "Artificial Intelligence", level: "Learning", description: "Exploring neural networks, deep learning models, natural language processing, and prompt engineering." },
  { topic: "Machine Learning", level: "Learning", description: "Understanding regression models, classifiers, data preprocessing steps, and statistical validation." },
  { topic: "GitHub & Open Source", level: "Active", description: "Learning branch workflows, pull requests, open-source contribution practices, and project boards." }
];

export const achievements: Achievement[] = [
  { label: "Projects Completed", value: 8, suffix: "+", icon: "CheckCircle" },
  { label: "Technologies Learned", value: 10, suffix: "+", icon: "Code" },
  { label: "Coding Hours", value: 500, suffix: "+", icon: "Clock" },
  { label: "GitHub Commits", value: 250, suffix: "+", icon: "GitCommit" }
];

export const futureGoals: Goal[] = [
  { title: "Become Full Stack Developer", description: "Bridge client-side applications with scalable node servers and secure cloud databases.", status: "in-progress" },
  { title: "Master Java Programming", description: "Achieve deep expertise in backend architectures, system designs, and competitive coding.", status: "in-progress" },
  { title: "Learn AI & ML Foundations", description: "Build deep neural networks and implement advanced cognitive systems from scratch.", status: "in-progress" },
  { title: "Build Real-world Projects", description: "Launch productive web and desktop apps solving genuine pain points for user groups.", status: "pending" },
  { title: "Contribute to Open Source", description: "Submit high-impact bug fixes and library enhancements to prominent global repositories.", status: "pending" }
];

export const testimonials: Testimonial[] = [
  {
    name: "Dr. K. Raghavan",
    role: "Professor of Computer Science, J.N.N IE",
    text: "Gomatha Priyan is an exceptionally diligent student. His logical clarity in Java Programming and curiosity towards Machine Learning are outstanding for a second-year student.",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80"
  },
  {
    name: "Arun Kumar G",
    role: "Senior Lead & Industry Mentor",
    text: "Collaborating with Priyan on coding workshops showed his natural affinity for frontend layout systems. He designs with a users-first approach that sets him apart.",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80"
  }
];

export const certificates: Certificate[] = [
  {
    title: "Java Programming Fundamentals",
    issuer: "Oracle Academy / Coursera",
    date: "May 2025",
    credentialUrl: "#"
  },
  {
    title: "Responsive Web Design Certification",
    issuer: "freeCodeCamp",
    date: "December 2024",
    credentialUrl: "#"
  },
  {
    title: "AI and Machine Learning Essentials",
    issuer: "NPTEL / Swayam",
    date: "April 2025",
    credentialUrl: "#"
  }
];
