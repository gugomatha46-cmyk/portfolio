import { useState } from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, Cpu, Code2, Hammer } from 'lucide-react';
import { skills } from '../data';

export default function Skills() {
  const [activeCategory, setActiveCategory] = useState<'all' | 'programming' | 'tools' | 'technologies'>('all');

  const categories = [
    { id: 'all', name: 'All Skills', icon: <ShieldCheck className="w-4 h-4" /> },
    { id: 'programming', name: 'Programming', icon: <Code2 className="w-4 h-4" /> },
    { id: 'tools', name: 'Tools', icon: <Hammer className="w-4 h-4" /> },
    { id: 'technologies', name: 'Technologies', icon: <Cpu className="w-4 h-4" /> }
  ];

  const filteredSkills = activeCategory === 'all'
    ? skills
    : skills.filter(s => s.category === activeCategory);

  // Split into circular and linear for visual variety
  const circularSkills = skills.filter(s => s.name === "Java Programming" || s.name === "Web Development" || s.name === "Artificial Intelligence");
  const linearSkills = filteredSkills;

  return (
    <section id="skills" className="py-24 bg-slate-950 relative overflow-hidden">
      {/* Background visual graphics */}
      <div className="absolute right-0 bottom-0 w-96 h-96 bg-teal-glow/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800 border border-white/5 text-xs font-semibold text-teal-glow tracking-wider uppercase mb-3"
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>Abilities</span>
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-3xl sm:text-4xl font-bold tracking-tight text-white"
          >
            Professional <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-glow to-cyan-glow">Skillset</span>
          </motion.h2>
          <motion.div
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="h-1 w-20 bg-gradient-to-r from-teal-glow to-cyan-glow mx-auto mt-4 rounded-full origin-left"
          />
        </div>

        {/* Core Circular Skills (Big feature dials) */}
        <div className="mb-16">
          <h3 className="text-center text-slate-400 text-sm font-semibold tracking-wider uppercase mb-8 font-mono">
            Core Competencies
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {circularSkills.map((skill, idx) => {
              const radius = 50;
              const circumference = 2 * Math.PI * radius;
              const strokeDashoffset = circumference - (skill.level / 100) * circumference;
              
              // Custom color gradient definitions for circular meters
              const colors = [
                { stroke: 'url(#cyanGrad)', text: 'text-cyan-glow', bg: 'rgba(0, 245, 255, 0.1)' },
                { stroke: 'url(#purpleGrad)', text: 'text-purple-glow', bg: 'rgba(123, 47, 247, 0.1)' },
                { stroke: 'url(#tealGrad)', text: 'text-teal-glow', bg: 'rgba(0, 201, 167, 0.1)' },
              ];
              const colorInfo = colors[idx % colors.length];

              return (
                <motion.div
                  key={skill.name}
                  className="glass-card rounded-2xl p-6 border border-white/5 flex flex-col items-center justify-center text-center shadow-xl group hover:border-white/10 hover:bg-slate-900/40 hover:scale-105 transition-all duration-300"
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: idx * 0.1 }}
                >
                  {/* SVG Circle indicator */}
                  <div className="relative w-32 h-32 flex items-center justify-center mb-4">
                    <svg className="w-full h-full transform -rotate-90">
                      <defs>
                        <linearGradient id="cyanGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                          <stop offset="0%" stopColor="#00F5FF" />
                          <stop offset="100%" stopColor="#00C9A7" />
                        </linearGradient>
                        <linearGradient id="purpleGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                          <stop offset="0%" stopColor="#7B2FF7" />
                          <stop offset="100%" stopColor="#00F5FF" />
                        </linearGradient>
                        <linearGradient id="tealGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                          <stop offset="0%" stopColor="#00C9A7" />
                          <stop offset="100%" stopColor="#7B2FF7" />
                        </linearGradient>
                      </defs>
                      {/* Gray track circle */}
                      <circle
                        cx="64"
                        cy="64"
                        r={radius}
                        className="stroke-slate-800"
                        strokeWidth="10"
                        fill="transparent"
                      />
                      {/* Active colored circle with animation */}
                      <motion.circle
                        cx="64"
                        cy="64"
                        r={radius}
                        stroke={colorInfo.stroke}
                        strokeWidth="10"
                        fill="transparent"
                        strokeDasharray={circumference}
                        initial={{ strokeDashoffset: circumference }}
                        whileInView={{ strokeDashoffset: strokeDashoffset }}
                        viewport={{ once: true }}
                        transition={{ duration: 1.5, ease: 'easeOut' }}
                        strokeLinecap="round"
                      />
                    </svg>
                    {/* Centered percentage text */}
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <span className="text-2xl font-bold text-white leading-none">{skill.level}%</span>
                      <span className="text-[10px] text-slate-500 uppercase font-mono mt-1">Level</span>
                    </div>
                  </div>

                  <h4 className="font-bold text-white text-base group-hover:text-cyan-glow transition-colors">
                    {skill.name}
                  </h4>
                  <p className="text-xs text-slate-400 mt-1 uppercase tracking-wider font-mono">
                    {skill.category}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Category filtering tab */}
        <div className="flex flex-wrap items-center justify-center gap-3 mb-12">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id as any)}
              className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold tracking-wider uppercase transition-all duration-200 border ${
                activeCategory === cat.id
                  ? 'bg-gradient-to-r from-purple-glow to-cyan-glow text-white border-transparent shadow-lg shadow-purple-glow/20'
                  : 'bg-slate-900 text-slate-400 border-white/5 hover:text-white hover:border-white/20'
              }`}
            >
              {cat.icon}
              <span>{cat.name}</span>
            </button>
          ))}
        </div>

        {/* Dynamic Skill Bars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {linearSkills.map((skill, idx) => (
            <motion.div
              key={skill.name}
              className="glass-card rounded-xl p-5 border border-white/5 hover:border-white/10 hover:bg-slate-900/30 transition-all duration-300 relative overflow-hidden group"
              initial={{ opacity: 0, x: idx % 2 === 0 ? -20 : 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: (idx % 4) * 0.1 }}
            >
              {/* Card top details */}
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-semibold text-white group-hover:text-cyan-glow transition-colors font-sans">
                  {skill.name}
                </span>
                <span className="text-xs font-bold text-cyan-glow bg-cyan-glow/5 border border-cyan-glow/10 px-2 py-0.5 rounded-full font-mono">
                  {skill.level}%
                </span>
              </div>

              {/* Progress bar outer track */}
              <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden relative">
                {/* Colored inner bar with motion entry */}
                <motion.div
                  className="h-full rounded-full bg-gradient-to-r from-purple-glow to-cyan-glow absolute left-0 top-0"
                  initial={{ width: '0%' }}
                  whileInView={{ width: `${skill.level}%` }}
                  viewport={{ once: true }}
                  transition={{ duration: 1.2, ease: 'easeOut' }}
                />
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
