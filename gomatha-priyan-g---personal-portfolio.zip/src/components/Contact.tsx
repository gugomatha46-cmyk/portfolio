import { useState, FormEvent, ChangeEvent } from 'react';
import { motion } from 'motion/react';
import { Send, Mail, MapPin, GraduationCap, CheckCircle2, AlertCircle } from 'lucide-react';
import { personalDetails } from '../data';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [formStatus, setFormStatus] = useState<'idle' | 'sending' | 'success' | 'error'>('idle');

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      setFormStatus('error');
      return;
    }

    setFormStatus('sending');

    // Simulate network submission delay
    setTimeout(() => {
      setFormStatus('success');
      setFormData({ name: '', email: '', subject: '', message: '' });
    }, 1500);
  };

  return (
    <section id="contact" className="py-24 bg-slate-950 relative overflow-hidden">
      {/* Ambient background light spheres */}
      <div className="absolute left-10 bottom-0 w-80 h-80 bg-purple-glow/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute right-1/4 top-1/3 w-96 h-96 bg-cyan-glow/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800 border border-white/5 text-xs font-semibold text-cyan-glow tracking-wider uppercase mb-3"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Connect</span>
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-3xl sm:text-4xl font-bold tracking-tight text-white"
          >
            Get In <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-glow to-teal-glow">Touch</span>
          </motion.h2>
          <motion.div
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="h-1 w-20 bg-gradient-to-r from-cyan-glow to-teal-glow mx-auto mt-4 rounded-full origin-left"
          />
        </div>

        {/* Content split grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 max-w-5xl mx-auto items-stretch">
          
          {/* Left Column: Contact details */}
          <motion.div
            className="lg:col-span-5 space-y-6 flex flex-col justify-between"
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8 }}
          >
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-white tracking-tight">
                Let's discuss your next <span className="text-cyan-glow">innovation</span>.
              </h3>
              <p className="text-sm sm:text-base text-slate-400 leading-relaxed">
                Whether you have an upcoming project, a Java-related problem, an AI modeling opportunity, or simply want to chat, my inbox is always open.
              </p>
            </div>

            {/* Quick Contact Info Cards */}
            <div className="space-y-4 py-6">
              <div className="flex items-center gap-4 p-4.5 rounded-xl glass-card border border-white/5 hover:border-cyan-glow/20 transition-all duration-300">
                <div className="p-3 rounded-lg bg-slate-950/60 border border-white/5 text-cyan-glow">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-[10px] font-mono uppercase tracking-wider text-slate-500 font-semibold">Direct Email</h4>
                  <a href={`mailto:${personalDetails.email}`} className="text-sm font-semibold text-white hover:text-cyan-glow transition-colors">
                    {personalDetails.email}
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-4 p-4.5 rounded-xl glass-card border border-white/5 hover:border-purple-glow/20 transition-all duration-300">
                <div className="p-3 rounded-lg bg-slate-950/60 border border-white/5 text-purple-glow">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-[10px] font-mono uppercase tracking-wider text-slate-500 font-semibold">Base Location</h4>
                  <span className="text-sm font-semibold text-white">
                    {personalDetails.location}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-4 p-4.5 rounded-xl glass-card border border-white/5 hover:border-teal-glow/20 transition-all duration-300">
                <div className="p-3 rounded-lg bg-slate-950/60 border border-white/5 text-teal-glow">
                  <GraduationCap className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-[10px] font-mono uppercase tracking-wider text-slate-500 font-semibold">Academic College</h4>
                  <span className="text-sm font-semibold text-white">
                    {personalDetails.college}
                  </span>
                </div>
              </div>
            </div>

            {/* Quick Footer indicator */}
            <div className="text-xs text-slate-500 font-mono">
              <span>Typically responds within 24 hours</span>
            </div>
          </motion.div>

          {/* Right Column: Contact form */}
          <motion.div
            className="lg:col-span-7"
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8 }}
          >
            <div className="glass-card rounded-2xl p-6 sm:p-8 border border-white/10 shadow-2xl h-full flex flex-col justify-center">
              {formStatus === 'success' ? (
                // Success Response Card
                <motion.div
                  className="text-center py-12 space-y-4"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                >
                  <div className="w-16 h-16 rounded-full bg-teal-glow/15 border-2 border-teal-glow flex items-center justify-center text-teal-glow mx-auto animate-bounce">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h3 className="text-2xl font-bold text-white tracking-tight">Message Dispatched!</h3>
                  <p className="text-slate-400 text-sm max-w-sm mx-auto">
                    Thank you for reaching out! Gomatha Priyan has received your transmission and will get back to you shortly.
                  </p>
                  <button
                    onClick={() => setFormStatus('idle')}
                    className="mt-6 px-5 py-2.5 rounded-full text-xs font-semibold text-cyan-glow bg-cyan-glow/10 border border-cyan-glow/25 hover:bg-cyan-glow/25 transition-all"
                  >
                    Send Another Message
                  </button>
                </motion.div>
              ) : (
                // Interactive Contact Form
                <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Name input */}
                    <div className="space-y-1.5">
                      <label htmlFor="name" className="text-xs font-semibold text-slate-300 font-sans">
                        Your Name <span className="text-purple-glow">*</span>
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                        placeholder="John Doe"
                        className="w-full px-4 py-2.5 rounded-xl bg-slate-950/80 border border-white/10 focus:border-cyan-glow/60 focus:ring-1 focus:ring-cyan-glow/40 text-sm text-white placeholder-slate-600 outline-none transition-all"
                      />
                    </div>

                    {/* Email input */}
                    <div className="space-y-1.5">
                      <label htmlFor="email" className="text-xs font-semibold text-slate-300 font-sans">
                        Your Email <span className="text-purple-glow">*</span>
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        placeholder="john@example.com"
                        className="w-full px-4 py-2.5 rounded-xl bg-slate-950/80 border border-white/10 focus:border-cyan-glow/60 focus:ring-1 focus:ring-cyan-glow/40 text-sm text-white placeholder-slate-600 outline-none transition-all"
                      />
                    </div>
                  </div>

                  {/* Subject input */}
                  <div className="space-y-1.5">
                    <label htmlFor="subject" className="text-xs font-semibold text-slate-300 font-sans">
                      Subject
                    </label>
                    <input
                      type="text"
                      id="subject"
                      name="subject"
                      value={formData.subject}
                      onChange={handleChange}
                      placeholder="Collaboration inquiry"
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-950/80 border border-white/10 focus:border-cyan-glow/60 focus:ring-1 focus:ring-cyan-glow/40 text-sm text-white placeholder-slate-600 outline-none transition-all"
                    />
                  </div>

                  {/* Message Input */}
                  <div className="space-y-1.5">
                    <label htmlFor="message" className="text-xs font-semibold text-slate-300 font-sans">
                      Message <span className="text-purple-glow">*</span>
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      required
                      rows={4}
                      placeholder="Write your message here..."
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-950/80 border border-white/10 focus:border-cyan-glow/60 focus:ring-1 focus:ring-cyan-glow/40 text-sm text-white placeholder-slate-600 outline-none transition-all resize-none"
                    />
                  </div>

                  {/* Error Notification banner */}
                  {formStatus === 'error' && (
                    <motion.div
                      className="flex items-center gap-2 p-3.5 rounded-xl bg-red-950/55 border border-red-900/40 text-red-400 text-xs"
                      initial={{ opacity: 0, y: -5 }}
                      animate={{ opacity: 1, y: 0 }}
                    >
                      <AlertCircle className="w-4 h-4 flex-shrink-0" />
                      <span>Please populate all required fields correctly before sending.</span>
                    </motion.div>
                  )}

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={formStatus === 'sending'}
                    className="w-full inline-flex items-center justify-center gap-2 py-3 rounded-xl font-semibold text-white bg-gradient-to-r from-purple-glow to-cyan-glow hover:brightness-110 shadow-lg shadow-purple-glow/20 hover:scale-[1.01] transition-all disabled:opacity-50"
                  >
                    <Send className="w-4 h-4 animate-pulse" />
                    <span>{formStatus === 'sending' ? 'Sending Message...' : 'Send Message'}</span>
                  </button>
                </form>
              )}
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
