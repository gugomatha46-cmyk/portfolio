import { motion } from 'motion/react';
import { GraduationCap, BookOpen, Calendar, MapPin } from 'lucide-react';
import { educationTimeline } from '../data';

export default function Timeline() {
  return (
    <section id="education" className="py-24 bg-slate-900 relative overflow-hidden">
      {/* Decorative ambient background lights */}
      <div className="absolute left-0 bottom-1/4 w-96 h-96 bg-cyan-glow/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto mb-20">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800 border border-white/5 text-xs font-semibold text-cyan-glow tracking-wider uppercase mb-3"
          >
            <GraduationCap className="w-3.5 h-3.5" />
            <span>Pathways</span>
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-3xl sm:text-4xl font-bold tracking-tight text-white"
          >
            Education <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-glow to-cyan-glow">Timeline</span>
          </motion.h2>
          <motion.div
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="h-1 w-20 bg-gradient-to-r from-purple-glow to-cyan-glow mx-auto mt-4 rounded-full origin-left"
          />
        </div>

        {/* Timeline representation */}
        <div className="relative mt-12">
          {/* Central Vertical Line (for md and up screens) */}
          <div className="absolute left-4 md:left-1/2 transform md:-translate-x-1/2 top-0 bottom-0 w-1 timeline-line rounded-full opacity-60" />

          {/* Timeline Items */}
          <div className="space-y-12">
            {educationTimeline.map((item, idx) => {
              const isEven = idx % 2 === 0;

              return (
                <div
                  key={item.id}
                  className={`flex flex-col md:flex-row ${
                    isEven ? 'md:flex-row-reverse' : ''
                  } items-start md:items-center relative`}
                >
                  {/* Timeline Badge Bubble */}
                  <div className="absolute left-4 md:left-1/2 transform -translate-x-1/2 flex items-center justify-center z-20">
                    <motion.div
                      className="w-10 h-10 rounded-full bg-slate-950 border-2 border-cyan-glow shadow-[0_0_12px_rgba(0,245,255,0.4)] flex items-center justify-center text-cyan-glow"
                      initial={{ scale: 0 }}
                      whileInView={{ scale: 1 }}
                      viewport={{ once: true }}
                      transition={{ type: 'spring', stiffness: 200, delay: idx * 0.2 }}
                    >
                      {idx === 0 ? <GraduationCap className="w-5 h-5" /> : <BookOpen className="w-5 h-5" />}
                    </motion.div>
                  </div>

                  {/* Empty space counterpart for centering on md+ */}
                  <div className="hidden md:block md:w-1/2 px-8" />

                  {/* Card Content Block */}
                  <motion.div
                    className="w-full md:w-1/2 pl-12 md:pl-0 md:px-8"
                    initial={{ opacity: 0, x: isEven ? 50 : -50 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true, margin: '-100px' }}
                    transition={{ duration: 0.8 }}
                  >
                    <div className="glass-card rounded-2xl p-6 border border-white/5 hover:border-cyan-glow/20 hover:bg-slate-800/40 hover:shadow-xl transition-all duration-300 relative group glow-border-cyan">
                      {/* Triangle Pointer Accent (visible on md+) */}
                      <div
                        className={`hidden md:block absolute top-1/2 transform -translate-y-1/2 w-3 h-3 bg-slate-900 border-t border-l border-white/5 rotate-45 ${
                          isEven
                            ? 'left-[-7px] border-r border-b border-t-0 border-l-0'
                            : 'right-[-7px]'
                        }`}
                      />

                      {/* Grade Badge */}
                      {item.grade && (
                        <div className="absolute top-6 right-6 px-2.5 py-0.5 rounded-full text-[10px] font-mono tracking-wider font-semibold text-teal-glow bg-teal-glow/10 border border-teal-glow/20">
                          {item.grade}
                        </div>
                      )}

                      {/* Header info */}
                      <div className="flex items-center gap-1.5 text-xs text-slate-400 mb-2 font-mono">
                        <Calendar className="w-3.5 h-3.5 text-purple-glow" />
                        <span>{item.period}</span>
                      </div>

                      <h3 className="text-xl font-bold text-white group-hover:text-cyan-glow transition-colors">
                        {item.degree}
                      </h3>
                      
                      <div className="text-sm font-semibold text-transparent bg-clip-text bg-gradient-to-r from-purple-glow to-cyan-glow mt-1">
                        {item.field}
                      </div>

                      <div className="text-slate-300 font-medium text-sm mt-3 flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-cyan-glow" />
                        {item.institution}
                      </div>

                      <p className="text-xs sm:text-sm text-slate-400 leading-relaxed mt-3">
                        {item.description}
                      </p>
                    </div>
                  </motion.div>
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </section>
  );
}
