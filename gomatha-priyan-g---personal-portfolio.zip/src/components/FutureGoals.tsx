import { motion } from 'motion/react';
import { Target, CheckCircle2, Circle, RefreshCw, Star } from 'lucide-react';
import { futureGoals } from '../data';

export default function FutureGoals() {
  const getStatusIcon = (status: 'completed' | 'in-progress' | 'pending') => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="w-5 h-5 text-teal-glow" />;
      case 'in-progress':
        return <RefreshCw className="w-5 h-5 text-cyan-glow animate-spin-slow" />;
      default:
        return <Circle className="w-5 h-5 text-purple-glow" />;
    }
  };

  return (
    <section id="goals" className="py-24 bg-slate-950 relative overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute left-10 bottom-10 w-96 h-96 bg-cyan-glow/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800 border border-white/5 text-xs font-semibold text-cyan-glow tracking-wider uppercase mb-3"
          >
            <Target className="w-3.5 h-3.5" />
            <span>Vision</span>
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-3xl sm:text-4xl font-bold tracking-tight text-white"
          >
            Future <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-glow to-teal-glow">Milestones</span>
          </motion.h2>
          <motion.div
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="h-1 w-20 bg-gradient-to-r from-cyan-glow to-teal-glow mx-auto mt-4 rounded-full origin-left"
          />
        </div>

        {/* Goals Grid Board */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 max-w-6xl mx-auto">
          {futureGoals.map((goal, idx) => (
            <motion.div
              key={goal.title}
              className="glass-card rounded-2xl p-6 border border-white/5 hover:border-purple-glow/20 bg-slate-900/40 hover:bg-slate-900/60 transition-all duration-300 relative flex flex-col justify-between group glow-border-purple"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
            >
              {/* Card Top */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  {/* Status Indicator Icon */}
                  <div className="p-2 rounded-lg bg-slate-950/60 border border-white/5">
                    {getStatusIcon(goal.status)}
                  </div>

                  {/* Status Badge */}
                  <span className={`text-[9px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                    goal.status === 'completed'
                      ? 'text-teal-glow bg-teal-glow/10'
                      : goal.status === 'in-progress'
                      ? 'text-cyan-glow bg-cyan-glow/10'
                      : 'text-purple-glow bg-purple-glow/10'
                  }`}>
                    {goal.status === 'in-progress' ? 'In Progress' : goal.status === 'completed' ? 'Completed' : 'Upcoming'}
                  </span>
                </div>

                <h3 className="text-base font-bold text-white group-hover:text-cyan-glow transition-colors leading-tight mb-2">
                  {goal.title}
                </h3>

                <p className="text-xs text-slate-400 leading-relaxed">
                  {goal.description}
                </p>
              </div>

              {/* Goal Footer info */}
              <div className="mt-6 pt-4 border-t border-slate-800/40 flex items-center gap-1.5 text-[10px] font-mono text-slate-500">
                <Star className="w-3.5 h-3.5 text-cyan-glow fill-cyan-glow/25" />
                <span>Goal {idx + 1} of 5</span>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
