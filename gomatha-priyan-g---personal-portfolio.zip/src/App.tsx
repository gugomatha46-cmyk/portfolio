import { useState, useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Timeline from './components/Timeline';
import Skills from './components/Skills';
import Projects from './components/Projects';
import Experience from './components/Experience';
import Achievements from './components/Achievements';
import FutureGoals from './components/FutureGoals';
import ShowcaseExtra from './components/ShowcaseExtra';
import Contact from './components/Contact';
import Footer from './components/Footer';
import CustomCursor from './components/CustomCursor';
import ParticlesBg from './components/ParticlesBg';

export default function App() {
  const [isDarkMode, setIsDarkMode] = useState(true);

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
  };

  useEffect(() => {
    // Mount the body class list according to theme state
    if (isDarkMode) {
      document.body.classList.remove('light-mode');
    } else {
      document.body.classList.add('light-mode');
    }
  }, [isDarkMode]);

  return (
    <div className={`relative min-h-screen transition-colors duration-300 ${isDarkMode ? 'dark' : ''}`} id="app-root">
      
      {/* Dynamic Background Particle System */}
      <ParticlesBg />

      {/* Modern Custom Follower Cursor */}
      <CustomCursor />

      {/* Sticky Header Navigation */}
      <Header isDarkMode={isDarkMode} toggleTheme={toggleTheme} />

      {/* Main Single Page Content Sections */}
      <main className="relative z-10" id="main-content">
        
        {/* 1. Hero Section */}
        <Hero />

        {/* 2. About Me Section */}
        <About />

        {/* 3. Education Timeline Section */}
        <Timeline />

        {/* 4. Skills Section */}
        <Skills />

        {/* 5. Projects Section */}
        <Projects />

        {/* 6. Experience Section (Currently Learning) */}
        <Experience />

        {/* 7. Achievements Section */}
        <Achievements />

        {/* 8. Future Goals Section */}
        <FutureGoals />

        {/* EXTRA FEATURES: Certs, Git Graph, Testimonials & Blogs */}
        <ShowcaseExtra />

        {/* 9. Contact Section */}
        <Contact />

      </main>

      {/* 10. Footer Section & Scroll Back-to-Top trigger */}
      <Footer />

    </div>
  );
}
