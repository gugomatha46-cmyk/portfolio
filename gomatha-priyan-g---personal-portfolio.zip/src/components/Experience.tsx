import { motion } from 'motion/react';
import { BookOpen, Sparkles, Star, Milestone, Compass } from 'lucide-react';
import { learningItems } from '../data';

export default function Experience() {
  return (
    <section id="experience" className="py-24 bg-slate-950 relative overflow-hidden">
      {/* Visual neon light spots */}
      <div className="absolute right-10 top-1/3 w-80 h-80 bg-purple-glow/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800 border border-white/5 text-xs font-semibold text-purple-glow tracking-wider uppercase mb-3"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Growth</span>
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-3xl sm:text-4xl font-bold tracking-tight text-white"
          >
            Experience & <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-glow to-cyan-glow">Currently Learning</span>
          </motion.h2>
          <motion.div
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="h-1 w-20 bg-gradient-to-r from-purple-glow to-cyan-glow mx-auto mt-4 rounded-full origin-left"
          />
        </div>

        {/* Learning Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {learningItems.map((item, idx) => (
            <motion.div
              key={item.topic}
              className="glass-card rounded-2xl p-6 border border-white/5 hover:border-cyan-glow/20 bg-slate-900/40 hover:bg-slate-900/60 transition-all duration-300 relative overflow-hidden group glow-border-cyan flex flex-col justify-between"
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
            >
              {/* Top Row: Title & badge */}
              <div>
                <div className="flex items-start justify-between mb-4">
                  <div className="p-2.5 rounded-lg bg-slate-950/60 border border-white/5 text-cyan-glow group-hover:scale-110 transition-transform">
                    <Milestone className="w-5 h-5" />
                  </div>
                  
                  {/* Status badge */}
                  <span className={`text-[10px] font-mono uppercase tracking-widest font-semibold px-2 py-0.5 rounded-full border ${
                    item.level === 'Advanced'
                      ? 'text-teal-glow bg-teal-glow/10 border-teal-glow/20'
                      : item.level === 'Intermediate'
                      ? 'text-cyan-glow bg-cyan-glow/10 border-cyan-glow/20'
                      : 'text-purple-glow bg-purple-glow/10 border-purple-glow/20'
                  }`}>
                    {item.level}
                  </span>
                </div>

                <h3 className="text-lg font-bold text-white group-hover:text-cyan-glow transition-colors mb-2">
                  {item.topic}
                </h3>
                
                <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                  {item.description}
                </p>
              </div>

              {/* Bottom decorative stats bar */}
              <div className="mt-6 pt-4 border-t border-slate-800/40 flex items-center justify-between text-[11px] font-mono text-slate-500">
                <span className="flex items-center gap-1">
                  <Star className="w-3 h-3 text-cyan-glow fill-cyan-glow" />
                  <span>Ongoing Study</span>
                </span>
                <span>Active Research</span>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
